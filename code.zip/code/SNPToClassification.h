// SNPToClassification.h: interface for the SNPToClassification class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SNPTOCLASSIFICATION_H__D4C6FFE4_38BE_4298_8DD8_520269FA057C__INCLUDED_)
#define AFX_SNPTOCLASSIFICATION_H__D4C6FFE4_38BE_4298_8DD8_520269FA057C__INCLUDED_
#pragma warning ( disable:4786)
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>//istringstream
#include <vector>
#include <math.h>
#include <time.h> 
#include <afx.h>
#include<stdlib.h>
#include "SVM.h"
#include "ReadFile.h"
using namespace std;
using std::vector;
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class SNPToClassification  
{
public:
	void GenomeWideSelection(vector<int> tags,vector<int> nontags);
	double CrossValidationExceptHighLD(vector<int> nontags,vector<int> tags);
	void BackwardNORemove(vector<int> tags);
	void BackwardNORemove(vector<int> tags,vector<int> nontags);
	void printToFile(vector<int> range);
	double Classification(vector<int>);

	double CrossValidation(vector< vector<int> > pop_int,int k);
	SNPToClassification();
	virtual ~SNPToClassification();
	void ConstructSVMProblem(vector< vector<int> > pop_int);
	void SNPToClassification::print(struct svm_problem range);
	//////////////////svm_train.c�ļ����е�ȫ�ֱ���ת��Ϊ��Ա����
	struct svm_parameter param;		// set by parse_command_line
	struct svm_model * model;
	//int cross_validation;//Bool�ͱ���
	int nr_fold;//nr��
	struct svm_problem prob;		// set by read_problem
	struct svm_node *x_space;
	//////////////////
	vector< vector<int> > m_binarySamples;
	vector<int> m_label;
	///////////////
	void SNPToClassification::TransformToDecimal(vector< vector<int> > DecimalSamples,vector<int> m_label);
	void BackwardRemoveAlgorithm(vector<int> tags);
	void SNPToClassification::print(vector<int> range);
	double print(vector<double> range);
	void print(vector< vector<int> > range);
};

#endif // !defined(AFX_SNPTOCLASSIFICATION_H__D4C6FFE4_38BE_4298_8DD8_520269FA057C__INCLUDED_)
