/////////////////////////////////////////
//���ļ���Ҫ�Ĺ����Ƕ�ȡָ����ʽ��SNP�ļ�
/////////////////////////////////////////

#if !defined(AFX_READFILE_H__4353E601_B1A1_4EC4_A1CD_B1A5EA0676B6__INCLUDED_)
#define AFX_READFILE_H__4353E601_B1A1_4EC4_A1CD_B1A5EA0676B6__INCLUDED_
#pragma warning(disable:4786)//ȥ��VC6.0������ʹ�õľ���

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>//istringstream
#include <algorithm>
#include <vector>
#include <math.h>
#include <time.h> 
#include <afx.h>
#include<stdlib.h>
using namespace std;
using std::vector;
//ȫ�ֱ���
struct SNP
{
	string id;
	string gene;	
};

typedef struct 
{
	string id;
	string allele_A;//major
	string allele_a;
	double A_fre;
	double a_fre;
	bool zero_variance;
}snp_global2;

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CReadFile  
{
public:
	CReadFile();
	virtual ~CReadFile();
	bool load();
	////////////////////
	string m_filename;
	///////////////////
	vector< vector<struct SNP> > pop;//ԭʼ֮�������
	vector< vector<string> > pop_string;
	vector< vector<int> > pop_int;
	vector<snp_global2> m_allele_fre;
	//////////////////////
	void ReadGenotype();
	bool checkvalid(vector< vector<struct SNP> > range);
	//�������
	void print( vector< vector<struct SNP> >);
	void print( vector<struct SNP>  range);
	void print( vector< vector<int> > range);
	void print( vector<int>  range);
	void print( vector< vector<string> >  range);

	void preproceed();//������Ԥ����

};

#endif // !defined(AFX_READFILE_H__4353E601_B1A1_4EC4_A1CD_B1A5EA0676B6__INCLUDED_)
