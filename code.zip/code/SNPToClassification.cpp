// SNPToClassification.cpp: implementation of the SNPToClassification class.
//
//////////////////////////////////////////////////////////////////////

#include "SNPToClassification.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#define Malloc(type,n) (type *)malloc((n)*sizeof(type))

string	filenameAcc="allsubsetAccuracy.txt";
extern ofstream foutAcc(filenameAcc.c_str());
SNPToClassification::SNPToClassification()
{
	// default values
	param.svm_type = C_SVC;
	param.kernel_type = RBF;
	param.degree = 3;
	//param.gamma = 0;	// 1/num_features
	param.gamma = 0.1;
	param.coef0 = 0;
	param.nu = 0.5;
	param.cache_size = 100;
	//param.C = 1;
	param.C = 100;
	param.eps = 1e-3;
	param.p = 0.1;
	param.shrinking = 1;
	param.probability = 0;
	param.nr_weight = 0;
	param.weight_label = NULL;
	param.weight = NULL;
	//cross_validation = 0;
	
}

SNPToClassification::~SNPToClassification()
{
	svm_destroy_param(&param);
}
void SNPToClassification::ConstructSVMProblem(vector< vector<int> > pop_int)
{
	///////////
	//struct svm_problem prob;		// set by read_problem
	//struct svm_node *x_space;
	//////////
	prob.l = 0;
	int elements=0;
	//int max_line_len = 1024;
	//char * line=Malloc(char,max_line_len);
	prob.l=pop_int.size();//������
	//�ܵ�svm_Node�ڵ�����pop_int��һ��ΪĿ�����ţ���svm_Node�����Ҫһ�������������Խڵ��������¼���
	elements=pop_int[0].size()*pop_int.size();
	prob.y = Malloc(double,prob.l);
	prob.x = Malloc(struct svm_node *,prob.l);
	x_space = Malloc(struct svm_node,elements);
	////////////��Ԫ���������µ�ַ��
	for(int m=0;m<prob.l;m++)//�����
	{
		prob.y[m]=pop_int[m][0];//��һ��ΪĿ������,Ҳ��Ϊ��Ԥ��ķ���ϢSNP
	}
	int j=0;
	for(m=0;m<prob.l;m++)//���svm_node
	{
		prob.x[m]=&x_space[j];//��¼ÿһ��svm_node���׵�ַ
		for(int n=1;n<pop_int[m].size();n++)//��һ����Ŀ������
		{
			x_space[j].index=n;//index��1��ʼ������
			x_space[j].value=pop_int[m][n];
			j++;
		}
		x_space[j].index=-1;//index��1��ʼ������
		j++;
	}
	///////////////
	//print(prob);
	//	return prob;
	
	
}
void SNPToClassification::print(struct svm_problem range)
{
	cout<<"l = "<<range.l<<endl;
	cout<<"y -> ";
	for(int i=0;i<range.l;i++)
	{
		cout<<range.y[i]<<" ";
	}
	cout<<endl;
	cout<<"x ->"<<endl;
	for(i=0;i<range.l;i++)
	{
		cout<<"[ ] -> ";
		int j=0;
		while(range.x[i][j].index!=-1)
		{
			cout<<"("<<range.x[i][j].index<<","<<range.x[i][j].value<<")"<<" ";
			j++;
		}
		cout<<"("<<range.x[i][j].index<<","<<range.x[i][j].value<<")"<<" "<<endl;
	}
}

double SNPToClassification::CrossValidation(vector< vector<int> > pop_int,int k)//K����֤
{
	nr_fold=k;
	///////////////
	ConstructSVMProblem(pop_int);
	double acc=0;
	///////////////
	int i;
	int total_correct = 0;
	double total_error = 0;
	double sumv = 0, sumy = 0, sumvv = 0, sumyy = 0, sumvy = 0;
	double *target = Malloc(double,prob.l);
	
	svm_cross_validation(&prob,&param,nr_fold,target);
	if(param.svm_type == EPSILON_SVR ||
		param.svm_type == NU_SVR)
	{
		for(i=0;i<prob.l;i++)
		{
			double y = prob.y[i];
			double v = target[i];
			total_error += (v-y)*(v-y);
			sumv += v;
			sumy += y;
			sumvv += v*v;
			sumyy += y*y;
			sumvy += v*y;
		}
		printf("Cross Validation Mean squared error = %g\n",total_error/prob.l);
		printf("Cross Validation Squared correlation coefficient = %g\n",
			((prob.l*sumvy-sumv*sumy)*(prob.l*sumvy-sumv*sumy))/
			((prob.l*sumvv-sumv*sumv)*(prob.l*sumyy-sumy*sumy))
			);
	}
	else
	{
		for(i=0;i<prob.l;i++)
			if(target[i] == prob.y[i])
				++total_correct;
			printf("Cross Validation Accuracy = %g%%\n",100.0*total_correct/prob.l);
	}
	acc=(double)total_correct/prob.l;//����׼ȷ��
	free(target);
	///////////////
	free(prob.y);
	free(prob.x);
	free(x_space);
	return acc;
}
void SNPToClassification::TransformToDecimal(vector< vector<int> > DecimalSamples,vector<int> label)
{
	m_binarySamples=DecimalSamples;
	m_label=label;

}
void SNPToClassification::printToFile(vector<int> range)
{
	for(int i=0;i<range.size();i++)
	{
		foutAcc<<range[i]<<" ";
	}
	foutAcc<<endl;
}
void SNPToClassification::print(vector<int> range)
{
	for(int i=0;i<range.size();i++)
	{
		cout<<range[i]<<" ";
	}
}
double SNPToClassification::print(vector<double> range)
{
	double acc=0;
	for(int i=0;i<range.size();i++)
	{
		cout<<range[i]<<" ";
		acc+=range[i];
	}
	double ave_acc=acc/range.size();
	cout<<"ave_acc="<<ave_acc<<endl;
	return ave_acc;
}
void SNPToClassification::print(vector< vector<int> > range)
{
	for( int i=0;i<range.size();i++)
	{
		for(int j=0;j<range[i].size();j++)
		{
			cout<<range[i][j]<<" ";
		}
		cout<<endl;
	}
}


double SNPToClassification::Classification(vector<int> tags)
{
	
	///////////
	vector<int> temp;
	vector< vector<int> > binarySamples;
	for(int i=0;i<m_binarySamples.size();i++)
	{
		binarySamples.push_back(temp);
		binarySamples[i].push_back(0);
	}
	for(i=0;i<m_binarySamples.size();i++)
	{
		for(int j=0;j<tags.size();j++)
		{
			binarySamples[i].push_back(m_binarySamples[i][tags[j]]);//׼��tags����
		}
	}
	vector<double> acc_list;
	//////////////////LOOV
	int nr_fold=m_binarySamples.size()-1;
	//////////////////
	SNPToClassification snp;
	
	for(i=0;i<m_binarySamples.size();i++)
	{
		binarySamples[i][0]=m_label[i];//׼��Ŀ������
	}
	//cout<<"׼��Ŀ�����ź�:"<<endl;
	//print(binarySamples);	cout<<endl;
	double acc;
	acc=snp.CrossValidation(binarySamples,nr_fold);
	acc_list.push_back(acc);
	
	return print(acc_list);
}

void SNPToClassification::BackwardRemoveAlgorithm(vector<int> tags)
{
	vector<int> ori_tags=tags;
	m_binarySamples.erase(m_binarySamples.begin());//ȥ�����к����е�������SNP��ID
	for(int i=0;i<m_binarySamples.size();i++)
		m_binarySamples[i].erase(m_binarySamples[i].begin());
	////////////////////
	double acc_max=Classification(tags);
	
	while(1)
	{
		bool changed=false;
		double acc=0;
		int potential_pos=-1;
		for(int i=0;i<tags.size();i++)
		{
			vector<int> tags_temp=tags;
			tags_temp.erase(tags_temp.begin()+i);
			acc=Classification(tags_temp);
			if(acc>=acc_max)
			{
				potential_pos=i;
				acc_max=acc;
				changed=true;
			}
			
		}
		if(changed)
		{
			if(potential_pos>=0)
				tags.erase(tags.begin()+potential_pos);
			//
		}
		else
		{
			break;
		}
	}
	
	cout<<"ori_tags:";
	print(ori_tags);
	cout<<endl;
	cout<<"acc_max="<<acc_max;
	cout<<endl;
	print(tags);
}

void SNPToClassification::BackwardNORemove(vector<int> tags)
{
	DWORD start =GetTickCount();
	vector<int> ori_tags=tags;
	//////////////////////////
	//m_binarySamples.erase(m_binarySamples.begin());//ȥ�����к����е�������SNP��ID
	//for(int i=0;i<m_binarySamples.size();i++)
	//	m_binarySamples[i].erase(m_binarySamples[i].begin());
	////////////////////
	double acc_max=Classification(tags);
	/////////////////////
	foutAcc<<"Greedy algorithm accuracy:"<<acc_max<<endl;
	printToFile(tags);
	foutAcc<<endl;
	int iter_num=tags.size();
	while(iter_num)
	{
		acc_max=0;//����
		double acc=0;
		int potential_pos=-1;
		for(int i=0;i<tags.size();i++)
		{
			vector<int> tags_temp=tags;
			tags_temp.erase(tags_temp.begin()+i);
			acc=Classification(tags_temp);
			if(acc>=acc_max)
			{
				potential_pos=i;
				acc_max=acc;
			}
			
		}
		if(potential_pos>=0)
			tags.erase(tags.begin()+potential_pos);
		foutAcc<<"the "<<iter_num<<"-th iteration's accuracy "<<acc_max<<endl;
		printToFile(tags);
		
		DWORD end =GetTickCount();
		foutAcc<<"��������ʱ��Ϊ��"<<end-start<<"ms"<<endl;
		foutAcc<<endl;
		iter_num--;
	}
	
}

double SNPToClassification::CrossValidationExceptHighLD(vector<int> nontags,vector<int> tags)
{
	//vector<int> nontags=GetNontags(tags);
	
	vector<int> temp;
	vector< vector<int> > binarySamples;
	for(int i=0;i<m_binarySamples.size();i++)
	{
		binarySamples.push_back(temp);
		binarySamples[i].push_back(0);
	}
	for(i=0;i<m_binarySamples.size();i++)
	{
		for(int j=0;j<tags.size();j++)
		{
			binarySamples[i].push_back(m_binarySamples[i][tags[j]]);//׼��tags����
		}
	}
	vector<double> acc_list;
	int nr_fold=m_binarySamples.size()-1;
	for(int j=0;j<nontags.size();j++)
	{	
		for(int i=0;i<m_binarySamples.size();i++)
		{
			binarySamples[i][0]=m_binarySamples[i][nontags[j]];//׼��Ŀ������
		}
		//cout<<"׼��Ŀ�����ź�:"<<endl;
		//print(binarySamples);	cout<<endl;
		SNPToClassification snp;
		double acc;
		acc=snp.CrossValidation(binarySamples,nr_fold);
		acc_list.push_back(acc);
	}
	return print(acc_list);
}
void SNPToClassification::BackwardNORemove(vector<int> tags,vector<int> nontags)
{
	DWORD start =GetTickCount();
	vector<int> ori_tags=tags;
	////////////////////
	//m_binarySamples.erase(m_binarySamples.begin());//ȥ�����к����е�������SNP��ID
	//for(int i=0;i<m_binarySamples.size();i++)
	//	m_binarySamples[i].erase(m_binarySamples[i].begin());
	////////////////////
	double acc_max=CrossValidationExceptHighLD(nontags,tags);
	/////////////////////
	foutAcc<<"Greedy algorithm accuracy:"<<acc_max<<endl;
	printToFile(tags);
	foutAcc<<endl;
	int iter_num=tags.size();
	while(iter_num)
	{
		acc_max=0;//����
		double acc=0;
		int potential_pos=-1;
		for(int i=0;i<tags.size();i++)
		{
			vector<int> tags_temp=tags;
			tags_temp.erase(tags_temp.begin()+i);
			//acc=CrossValidationAllNontags(tags_temp);
			acc=CrossValidationExceptHighLD(nontags,tags_temp);
			if(acc>=acc_max)
			{
				potential_pos=i;
				acc_max=acc;
			}
			
		}
		if(potential_pos>=0)
			tags.erase(tags.begin()+potential_pos);
		foutAcc<<"the "<<iter_num<<"-th iteration's accuracy "<<acc_max<<endl;
		printToFile(tags);
		
		DWORD end =GetTickCount();
		foutAcc<<"��������ʱ��Ϊ��"<<end-start<<"ms"<<endl;
		foutAcc<<endl;
		iter_num--;
	}
	
}

void SNPToClassification::GenomeWideSelection(vector<int> tags,vector<int> nontags)
{
	//���ģ���������Ż���1��LD��2��W��3��ֻ��һ��Ԥ��
	DWORD start =GetTickCount();
	vector<int> ori_tags=tags;
	/////////////////////////
	//m_binarySamples.erase(m_binarySamples.begin());//ȥ�����к����е�������SNP��ID
	//for(int i=0;i<m_binarySamples.size();i++)
	//	m_binarySamples[i].erase(m_binarySamples[i].begin());
	////////////////////
	double acc_max=CrossValidationExceptHighLD(nontags,tags);
	foutAcc<<"Greedy algorithm accuracy:"<<acc_max<<endl;
	printToFile(tags);
	foutAcc<<endl;
	DWORD end =GetTickCount();
	foutAcc<<"��������ʱ��Ϊ��"<<end-start<<"ms"<<endl;
	foutAcc<<endl;
}
