% function [fitness,XX] = origPSO(POPsize,Dimension,Xmin,Xmax,Vmin,Vmax)
% function fitness = origPSO(c1,c2)
%
% The function is to optimize the value of object function by using the
% original particle swarm optimization algorithm.
% 
% Define variables:
% FuncResult -- save the best fitness of each iteriation
% X -- the current position of particle
% V -- the current speed of particle
% Xf -- the current fitness of particle
% Xbf -- the current best fitness of particle
% Vmax -- the limit of velocity
% Xmax -- the upper of position
% Xmin -- the lower of position
% c1 -- accelerating coefficient of cognition
% c2 -- accelerating coefficient of social
% fitness -- the best fitness of particle
% gBest -- the best position of swarm
% pBest -- the best position of particle
% w -- inertia weight
% 
% Record of revisions:
% Date Programmer Description of change
% ==== ========== =====================
% 03/02/09 Z. W. Qiao Original code
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

POPsize=50;Dimension=2;Xmin=[-2,-2];Xmax=[2,2];Vmin=[-2,-2];Vmax=[2,2];

IterMax = 1000;

w=1.0;
c1=2;
c2=2;


InnerIter = 0;
OuterIter = 0;
% 
ll = 1;
T = 0;
while (ll <= 50) & (T == 0)
    % initialization
    number = 0;
    for ii = 1 : POPsize
            X(ii,1) = rand * (Xmax(1) - Xmin(1)) + Xmin(1);
            V(ii,1) = rand * (Vmax(1) - Vmin(1)) + Vmin(1);
            X(ii,2) = rand * (Xmax(2) - Xmin(2)) + Xmin(2);
            V(ii,2) = rand * (Vmax(2) - Vmin(2)) + Vmin(2);
    end
    pBest = X;
    for ii = 1 : POPsize
        Xf(ii) = calculationfitness(X,ii);
        Xbf(ii) = Xf(ii);
    end
    globalbest;
    %__________________________Initialize Over_____________________________
    %
    kk = length(FuncResult);
    fitness = FuncResult(kk);
    XX = gBest;
    for iter = 1 : IterMax
        if fitness < 1.0000e+005
            stopcond = abs(FuncResult(kk) - FuncResult(kk-1));
            precision = 0.0001;
            if stopcond < precision
               InnerIter = InnerIter + 1;
               OuterIter = OuterIter + 1;
               T = 1;
               break;
            else
                for ii = 1 : POPsize
                    for jj = 1 : Dimension
                        if jj == 1
                            V(ii,jj) = w * V(ii,jj) + c1 * rand * (pBest(ii,jj) - X(ii,jj)) + c2 * rand * (gBest(jj) - X(ii,jj));
                            if V(ii,jj) > Vmax(jj)
                                V(ii,jj) = Vmax(jj);
                            end
                            if V(ii,jj) < Vmin(jj)
                                V(ii,jj) = Vmin(jj);
                            end
                            X(ii,jj) = X(ii,jj) + V(ii,jj);
                            if X(ii,jj) > Xmax(jj)
                                X(ii,jj) = 2*Xmax(jj)-X(ii,jj);
                            end
                            if X(ii,jj) < Xmin(jj)
                                X(ii,jj) = 2*Xmin(jj)-X(ii,jj);
                            end
                        end
                    end
                    Xf(ii) = calculationfitness(X,ii);
                    localbest;
                end
                globalbest;
                kk = length(FuncResult);
                fitness = FuncResult(kk);
                XX = gBest;
            end
        else
            break
        end
        InnerIter = InnerIter + 1;
    end
    ll = ll + 1;
    OuterIter = OuterIter + 1;   
end
fitness
XX

