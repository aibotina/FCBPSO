function Y = calculationfitness(X,ii)


% Script file: calculatefitness.m
%
% Purpose:
% This program to calculate the fitness of particle.
%
% Record of revisions:
% Date Programmer Description of change
% ==== ========== =====================
% 03/02/09 Z. W. Qiao Original code
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
s = 1 + (1 + X(ii,1) + X(ii,2))^2 * (19 - 14 * X(ii,1) - 14 * X(ii,2)+ 3 * X(ii,1)^2 + 3 * X(ii,2)^2 + 6 * X(ii,1) * X(ii,2));
h = 30 + (2 * X(ii,1) - 3 * X(ii,2))^2 * (18 - 32 * X(ii,1) + 48 * X(ii,2) + 12 * X(ii,1)^2 + 27 * X(ii,2)^2 - 36 * X(ii,1) * X(ii,2));
Y = s * h;
% Y=Xf(ii);

% Xf(ii) = X(ii,1)^2 + X(ii,2)^2;

% s = sqrt(X(ii,1)^2 + X(ii,2)^2);
% h = (sin(s))^2 - 0.5;
% p = (1 + 0.001 * (X(ii,1)^2 + X(ii,2)^2))^2;
% Xf(ii) = h / p - 0.5;

% Xf(ii) = 10 * (X(ii,1) + X(ii,2)- 5)^2 + (X(ii,1) - X(ii,2))^2;

% s = 1 / (1 + (X(ii,1) - X(ii,2))^2);
% h = sin(0.5 * pi * X(ii,2) * X(ii,3));
% p = exp(-((X(ii,1) + X(ii,3)) / X(ii,2) - 2)^2);
% Xf(ii) = -(s + h + p);

% for ni = 1:4
%     Xf(ii) = 100 * (X(ii,ni+1) - X(ii,ni)^2)^2 + (X(ii,ni) - 1)^2;
% end







