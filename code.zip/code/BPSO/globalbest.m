% Script file: globalbest.m
%
% Purpose:
% This program to choose the best position of swarm.
%
% Record of revisions:
% Date Programmer Description of change
% ==== ========== =====================
% 03/02/09 Z. W. Qiao Original code
%
% Define variables:
% FuncResult -- save the best fitness of each iteriation
% X -- the current position of particle
% Xf -- the current fitness of particle
% Xbf -- the current best fitness of particle
% gBest -- the best position of swarm
% pBest -- the best position of particle
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if number == 0
    AF = Xbf(1);
    BF = Xbf(2);
    if AF < BF
        FuncResult(1) = BF;
        FuncResult(2) = AF;
    else
        FuncResult(1) = AF;
        FuncResult(2) = BF;
    end
    kt = 2;
    tt = 2;
    for ii = 3 : POPsize
        if Xf(ii) < FuncResult(tt)
            tt = tt + 1;
            FuncResult(tt) = Xbf(ii);
            kt = ii;
        end
    end
    gBest = X(kt,:);
    number = 1;
else
    for ii = 1 : POPsize
        if Xbf(ii) < FuncResult(tt)
            gBest = pBest(ii,:);
            tt = tt + 1;
            FuncResult(tt) = Xbf(ii);
        end
    end
end