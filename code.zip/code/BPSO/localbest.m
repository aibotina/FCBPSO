% Script file: localbest.m
%
% Purpose:
% This program to choose the best position of particle.
%
% Record of revisions:
% Date Programmer Description of change
% ==== ========== =====================
% 03/02/09 Z. W. Qiao Original code
%
% Define variables:
% X -- the current position of particle
% Xf -- the current fitness of particle
% Xbf -- the current best fitness of particle
% pBest -- the best position of particle
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Xbf(ii) > Xf(ii)
    pBest(ii,:) = X(ii,:);
    Xbf(ii) = Xf(ii);
end