// LDCalculation.cpp: implementation of the LDCalculation class.
//
//////////////////////////////////////////////////////////////////////

#include "LDCalculation.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
void print(vector< vector<string> > range);
void print(haps_fre range);
void print(vector<string>range);

void LDCalculation::countAllSNPFre(vector<int> SNPs_index)
{
	//////////////////��ȡ����λ���major,minor��Ƶ��
	for(int i=0;i<SNPs_index.size();i++)
	{
		snp_global temp_snp;
		vector<int> index_temp;
		index_temp.push_back(SNPs_index[i]);
		haps_fre hap_temp=countFre(index_temp);
		if(hap_temp.fre[0]>hap_temp.fre[1])//����λ����,�ҳ�major
		{
			temp_snp.allele_A=hap_temp.haps[0][0];
			temp_snp.A_fre=hap_temp.fre[0];
			temp_snp.allele_a=hap_temp.haps[1][0];
			temp_snp.a_fre=hap_temp.fre[1];
		}
		else
		{
			temp_snp.allele_A=hap_temp.haps[1][0];
			temp_snp.A_fre=hap_temp.fre[1];
			temp_snp.allele_a=hap_temp.haps[0][0];
			temp_snp.a_fre=hap_temp.fre[0];
		}
		m_allele_fre.push_back(temp_snp);
	}
}
LDCalculation::LDCalculation()
{	/*LD=1
	//1 haplotypes	
	vector<string> a;
	m_hapFre.haps.push_back(a);
	for(int i=0;i<10;i++)
	{
		m_hapFre.haps[0].push_back("1");
	}
	//2 haplotypes	
	m_hapFre.haps.push_back(a);
	m_hapFre.fre.push_back(0.75);
	for(i=0;i<10;i++)
	{
		m_hapFre.haps[1].push_back("2");
	}
	m_hapFre.fre.push_back(0.25);
	print(m_hapFre.haps);
	*/

	///*LD=0
	//1 haplotypes	
	vector<string> a;
	m_hapFre.haps.push_back(a);
	for(int i=0;i<10;i++)
	{
		m_hapFre.haps[0].push_back("1");
	}
	m_hapFre.fre.push_back(0.25);	
	//2 haplotypes	
	m_hapFre.haps.push_back(a);
	for(i=0;i<10;i++)
	{
		m_hapFre.haps[1].push_back("2");
	}
	m_hapFre.fre.push_back(0.25);
	//3 haplotypes	
	m_hapFre.haps.push_back(a);
	for(i=0;i<10;i++)
	{
		if(i%2==0)
			m_hapFre.haps[2].push_back("2");
		else
			m_hapFre.haps[2].push_back("1");
	}
	m_hapFre.fre.push_back(0.25);
	//4 haplotypes	
	m_hapFre.haps.push_back(a);
	for(i=0;i<10;i++)
	{
		if(i%2==1)
			m_hapFre.haps[3].push_back("2");
		else
			m_hapFre.haps[3].push_back("1");
	}
	m_hapFre.fre.push_back(0.25);
	//*/
	/*
	//////LD=0.33
	//1 haplotypes	
	vector<string> a;
	m_hapFre.haps.push_back(a);
	for(int i=0;i<10;i++)
	{
		m_hapFre.haps[0].push_back("1");
	}
	m_hapFre.fre.push_back(0.5);	
	//2 haplotypes	
	m_hapFre.haps.push_back(a);
	for(i=0;i<10;i++)
	{
		m_hapFre.haps[1].push_back("2");
	}
	m_hapFre.fre.push_back(0.25);
	//3 haplotypes	
	m_hapFre.haps.push_back(a);
	for(i=0;i<10;i++)
	{
		if(i%2==0)
			m_hapFre.haps[2].push_back("2");
		else
			m_hapFre.haps[2].push_back("1");
	}
	m_hapFre.fre.push_back(0.25);
	*/
	print(m_hapFre);
}

void LDCalculation::calculate()
{
	vector<int> SNP_pos;
	//for(int i=0;i<2;i++)
//	{
	//	SNP_pos.push_back(i);
//	}

	SNP_pos.push_back(0);
	SNP_pos.push_back(1);
	countAllSNPFre(SNP_pos);
	cout<<"r_square="<<r_square(6,7)<<endl;	
	cout<<"epsilon="<<epsilon(SNP_pos)<<endl;
	cout<<"epsilon_sub="<<epsilon_sub(SNP_pos)<<endl;
	cout<<"ER="<<ER(SNP_pos)<<endl;

}
LDCalculation::~LDCalculation()
{

}
void print(vector<snp_global> SNP_info) 
{
	for( int i=0;i<SNP_info.size();i++)
	{
		cout<<SNP_info[i].id<<":";
		cout<<" major="<<SNP_info[i].allele_A<<"  fre="<<SNP_info[i].A_fre;
		cout<<" minor="<<SNP_info[i].allele_a<<"  fre="<<SNP_info[i].a_fre;
		cout<<endl;
	}
}
void LDCalculation::initial(vector<snp_global2> SNP_info,vector< vector<string> > pop_string)
{
	snp_global allele_fre;
	for(int i=0;i<SNP_info.size();i++)
	{
		if(!SNP_info[i].zero_variance)
		{
			allele_fre.id=SNP_info[i].id;
			allele_fre.allele_A=SNP_info[i].allele_A;
			allele_fre.allele_a=SNP_info[i].allele_a;
			allele_fre.A_fre=SNP_info[i].A_fre;
			allele_fre.a_fre=SNP_info[i].a_fre;
			m_allele_fre.push_back(allele_fre);
		}
	}
	print(m_allele_fre);
	//////////////////////�����������SNP�ĵ����͵ĸ��ʷֲ�
	//////////pop_stringȥ����������
	pop_string.erase(pop_string.begin());
	for(i=0;i<pop_string.size();i++)
	{
		pop_string[i].erase(pop_string[i].begin());
	}
	////////////////
	for(i=0;i<pop_string.size();i++)
	{
		bool rep=false;
		for(int j=0;j<m_hapFre.haps.size();j++)
		{
			if(pop_string[i]==m_hapFre.haps[j])
			{
				rep=true;
				m_hapFre.fre[j]++;
				break;
			}
		}
		if(!rep)
		{
			m_hapFre.haps.push_back(pop_string[i]);	
			m_hapFre.fre.push_back(1);
		}		
	}
	for(i=0;i<m_hapFre.haps.size();i++)
	{
		m_hapFre.fre[i]=m_hapFre.fre[i]/(pop_string.size());
	}
	print(m_hapFre);
	//////////////////////
}
void print(vector< vector<string> > range)
{
	for(int i=0;i<range.size();i++)
	{
		for(int j=0;j<range[i].size();j++)
		{
			cout<<range[i][j]<<"	";
		}
		cout<<endl;
	}
}
double LDCalculation::ER(vector<int> SNPs_index)
{
	//////////////////E_max
	double H_max=0;
	double H_total=0;
	for(int i=0;i<SNPs_index.size();i++)
	{		
		//ע�����Ӹ���
		double H_temp=-(m_allele_fre[i].A_fre*(log(m_allele_fre[i].A_fre)/log(2))+m_allele_fre[i].a_fre*(log(m_allele_fre[i].a_fre)/log(2)));
		if(H_temp>H_max)
			H_max=H_temp;
		H_total+=H_temp;

	}
	double E_max=H_total-H_max;
	//////////////////E
	haps_fre observed_haps=countFre(SNPs_index);
	double E=0;
	for(i=0;i<observed_haps.haps.size();i++)
	{
		double fre_temp=observed_haps.fre[i];
		double fre_total=1;
		for(int j=0;j<SNPs_index.size();j++)
		{
			if(observed_haps.haps[i][j]==m_allele_fre[j].allele_A)
			{
				fre_total*=m_allele_fre[j].A_fre;
			}
			else
			{
				fre_total*=m_allele_fre[j].a_fre;
			}
		}
		E+=fre_temp*log(fre_temp/fre_total)/log(2);
	}
	//////////////////
	double ER=E/E_max;
	return ER;

}
double LDCalculation::epsilon_sub(vector<int> SNPs_index)
{
	double epsilon_sub=0;
	double sub=(double)SNPs_index.size()/(double)(SNPs_index.size()-1);
	epsilon_sub=epsilon(SNPs_index)*sub;
	return epsilon_sub;
}
double LDCalculation::epsilon(vector<int> SNPs_index)
{
	double epsilon=0;
	haps_fre observed_haps=countFre(SNPs_index);
	double H=0;
	//////////////////H_LD
	for(int i=0;i<observed_haps.haps.size();i++)
	{
		double fre_temp=observed_haps.fre[i];
		H+=fre_temp*(log(fre_temp)/log(2));//��2Ϊ�׵ļ��㷽��
	}	
	//////////////////��ȡ����λ���major,minor��Ƶ��
	/*
	vector<snp_global> allele_fre;
	for(i=0;i<SNPs_index.size();i++)
	{
		snp_global temp_snp;
		vector<int> index_temp;
		index_temp.push_back(SNPs_index[i]);
		haps_fre hap_temp=countFre(index_temp);
		if(hap_temp.fre[0]>hap_temp.fre[1])//����λ����
		{
			temp_snp.allele_A=hap_temp.haps[0][0];
			temp_snp.A_fre=hap_temp.fre[0];
			temp_snp.allele_a=hap_temp.haps[1][0];
			temp_snp.a_fre=hap_temp.fre[1];
		}
		else
		{
			temp_snp.allele_A=hap_temp.haps[1][0];
			temp_snp.A_fre=hap_temp.fre[1];
			temp_snp.allele_a=hap_temp.haps[0][0];
			temp_snp.a_fre=hap_temp.fre[0];
		}
		allele_fre.push_back(temp_snp);
	}
	*/
	//////////////////��������ƽ���µ��������У�H_LE
	double H_LE=0;
	haps_fre LE_haps;
	int total_haps=pow(2,SNPs_index.size());
	vector<string> hap_temp;
	for(i=0;i<total_haps;i++)
	{
		LE_haps.fre.push_back(1);
		LE_haps.haps.push_back(hap_temp);
	}

	for(int j=0;j<SNPs_index.size();j++)
	{
		int jump=total_haps/(pow(2,j+1));
		for( int i=0,k=1;i<total_haps;i+=jump,k++)
		{
			for(int l=i;l<jump+i;l++)
			{
				if(k%2!=0)
				{
					LE_haps.haps[l].push_back(m_allele_fre[j].allele_A);
					LE_haps.fre[l]*=m_allele_fre[j].A_fre;
				}
				else
				{
					LE_haps.haps[l].push_back(m_allele_fre[j].allele_a);
					LE_haps.fre[l]*=m_allele_fre[j].a_fre;
				}
			}
		}
	}
	//print(LE_haps);
	for(i=0;i<LE_haps.haps.size();i++)
	{
		H_LE+=LE_haps.fre[i]*(log(LE_haps.fre[i])/log(2));
	}
	epsilon=1-(H/H_LE);
	return epsilon;
}

double LDCalculation::r_square(int locus1,int locus2)
{
	double r2=0;
	struct snp_temp
	{
		string allele;
		double fre;
	};
	struct snp_temp SNP_locusA;
	SNP_locusA.allele=m_allele_fre[locus1].allele_A;
	SNP_locusA.fre=m_allele_fre[locus1].A_fre;
	/////////////////
	//cout<<"locus1 id="<<m_allele_fre[locus1].id<<endl;
	//cout<<"SNP_locusA.fre="<<SNP_locusA.fre<<endl;
	////////////
	struct snp_temp SNP_locusB;
	SNP_locusB.allele=m_allele_fre[locus2].allele_A;
	SNP_locusB.fre=m_allele_fre[locus2].A_fre;
	////////////
	//cout<<"locus2 id="<<m_allele_fre[locus2].id<<endl;
	//cout<<"SNP_locusB.fre="<<SNP_locusB.fre<<endl;
	//////////////////
	haps_fre temp;//��observed haplotypes��Ƶ��
	vector<int> index;
	index.push_back(locus1);
	index.push_back(locus2);
	temp=countFre(index);
	cout<<"temp=countFre(index):"<<endl;
	print(temp);
	/////////////////
	vector<string> haplotype;
	double freAB=0;
	haplotype.push_back(SNP_locusA.allele);
	haplotype.push_back(SNP_locusB.allele);
	cout<<"haplotyp=";
	print(haplotype);
	cout<<endl;
	for(int i=0;i<temp.haps.size();i++)
	{
		cout<<"temp.haps[i]=";
		print(temp.haps[i]);
		cout<<endl;
		if(haplotype==temp.haps[i])
		{
			freAB=temp.fre[i];
		}
	}
	double D=freAB-SNP_locusA.fre*SNP_locusB.fre;
	cout<<"freAB="<<freAB<<endl;
	cout<<"SNP_locusA.fre="<<SNP_locusA.fre<<endl;
	cout<<"SNP_locusB.fre="<<SNP_locusB.fre<<endl;
	cout<<"D="<<D<<endl;
	r2=pow(D,2)/(SNP_locusA.fre*SNP_locusB.fre*(1-SNP_locusA.fre)*(1-SNP_locusB.fre));
	cout<<"pow(D,2)="<<pow(D,2)<<endl;
	cout<<"fA="<<SNP_locusA.fre<<endl;
	cout<<"fa="<<1-SNP_locusA.fre<<endl;
	cout<<"fB="<<SNP_locusB.fre<<endl;
	cout<<"fb="<<1-SNP_locusB.fre<<endl;
	cout<<"fAfBfafb="<<SNP_locusA.fre*SNP_locusB.fre*(1-SNP_locusA.fre)*(1-SNP_locusB.fre)<<endl;
	///////////D_sub
	double D_sub=0;
	if(D<0)
	{
		double fAfb=SNP_locusA.fre*(1-SNP_locusB.fre);
		cout<<"fAfb="<<fAfb<<endl;
		double fafB=(1-SNP_locusA.fre)*SNP_locusB.fre;
		cout<<"fafB="<<fafB<<endl;
		double min=fAfb>fafB?fafB:fAfb;
		cout<<"min="<<min<<endl;
		D_sub=pow(D,2)/min;
	}
	else
	{
		double fAfB=SNP_locusA.fre*SNP_locusB.fre;
		cout<<"fAfB="<<fAfB<<endl;
		double fafb=(1-SNP_locusA.fre)*(1-SNP_locusB.fre);
		cout<<"fafb="<<fafb<<endl;

		double min=fAfB>fafb?fafb:fAfB;
		cout<<"min="<<min<<endl;
		D_sub=pow(D,2)/min;
	}
	cout<<"D_sub="<<D_sub<<endl;
	///////////
	return r2;
}

haps_fre  LDCalculation::countFre(vector<int> SNPs_index)
{
	haps_fre temp;
	for(int i=0;i<m_hapFre.haps.size();i++)
	{
		vector<string> hap_temp;
		for(int j=0;j<SNPs_index.size();j++)
		{
			hap_temp.push_back(m_hapFre.haps[i][SNPs_index[j]]);//ȡ����λ�����쵥����			
		}

		bool rep=false;
		for(int k=0;k<temp.haps.size();k++)
		{
			if(hap_temp==temp.haps[k])
			{
				temp.fre[k]+=m_hapFre.fre[i];
				rep=true;
				break;
			}
		}
		if(!rep)
		{
			temp.haps.push_back(hap_temp);
			temp.fre.push_back(m_hapFre.fre[i]);
		}
	}
	//print(temp);
	return temp;
}
void print(haps_fre range)
{
	for( int i=0;i<range.haps.size();i++)
	{
		for(int j=0;j<range.haps[i].size();j++)
		{
			cout<<range.haps[i][j];
		}
		cout<<"	"<<range.fre[i]<<endl;
	}
	cout<<" the number of haps is "<< range.haps.size()<<endl;
}

void print(vector<string>range) 
{
	for( int i=0;i<range.size();i++)
	{
		cout<<range[i]<<" ";
	}
}

